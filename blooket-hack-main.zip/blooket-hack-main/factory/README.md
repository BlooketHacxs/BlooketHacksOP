# Support discord server: https://glizzers.xyz/discord

# factory

This cheat only works in factory game mode!

# getCash.js

### Get the script from the file [getCash.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/factory/getCash.js) or https://schoolcheats.net/blooket

# getMegaBot.js

### Get the script from the file [getMegaBot.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/factory/getMegaBot.js) or https://schoolcheats.net/blooket
